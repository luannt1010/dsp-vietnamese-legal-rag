# Overleaf package with pre-rendered figures

Upload this ZIP as a NEW Overleaf project. Select XeLaTeX as the compiler and
Report_dsp.tex as the main document, then click Recompile. The report text,
tables, captions, references and cross-references remain editable.

The 12 diagrams/plots are embedded vector PDF files under figures/rendered/.
TikZ/PGFPlots are not loaded during report compilation. This reduces repeated
work; it does not change Overleaf's plan limits. The package has been compiled
locally; successful compilation inside a particular Overleaf account is not
guaranteed, and no paid-account features are used by this source.

Edit chapter text under chapters/. To change chart values or diagram designs,
edit the original reports/latex source in the repository, then regenerate this
package with build_overleaf.py. Changing CSV files here alone does not redraw
the already rendered figures. The original full-source ZIP remains available.

All figure fonts are embedded. Body fonts use the original automatic fallbacks;
Overleaf may substitute Carlito/TeX Gyre fonts, changing line/page breaks.
The first compile may need extra passes for references. If a compile times out,
check the first actual error with Stop on first error before retrying.
